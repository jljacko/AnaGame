#include "stdafx.h"
#include "Float.h"
#include "Short.h"

Float::Float()
{
}


Float::~Float()
{
}


float Float::getValue()
{
	return value;
}

void Float::setValue(float i)
{
	value = i;
}

TString Float::toString()
{
	TString ret;
	ret.Format(L"%d", value);
	return ret;
}



float Float::operator=(float i)
{
	return value = i;
}

float Float::operator=(Float & i)
{
	return value = i.getValue();
}

float Float::operator=(Short & s)
{
	return value = s.getValue();
}

float Float::operator+(float i)
{
	return value + i;
}

float Float::operator+=(float i)
{
	return value += i;
}

float Float::operator+(Float & i)
{
	return value + i.getValue();
}

float Float::operator+=(Float & i)
{
	return value += i.getValue();
}

float Float::operator-(float i)
{
	return value - i;
}

float Float::operator-=(float i)
{
	return value -= i;
}

float Float::operator-(Float & i)
{
	return value - i.getValue();
}

float Float::operator-=(Float & i)
{
	return value -= i.getValue();
}

float Float::operator*(float i)
{
	return value * i;
}

float Float::operator*=(float i)
{
	return value *= i;
}

float Float::operator*(Float & i)
{
	return value * i.getValue();
}

float Float::operator*=(Float & i)
{
	return value *= i.getValue();
}

float Float::operator/(float i)
{
	return value / i;
}

float Float::operator/=(float i)
{
	return value /= i;
}

float Float::operator/(Float & i)
{
	return value / i.getValue();
}

float Float::operator/=(Float & i)
{
	return value /= i.getValue();
}