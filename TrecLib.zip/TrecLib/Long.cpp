#include "stdafx.h"
#include "Long.h"

#include "Short.h"
#include "Integer.h"



Long::Long()
{
	value = 0;
}

Long::Long(long long l)
{
	value = l;
}


Long::Long(Long & l)
{
	value = l.getValue();
}

Long::Long(Integer & i)
{
	value = i.getValue();
}

Long::Long(Short & s)
{
	value = s.getValue();
}

Long::~Long()
{
}

long long Long::getValue()
{
	return value;
}

void Long::setValue(long long i)
{
	value = i;
}

TString Long::toString()
{
	TString ret;
	ret.Format(L"%d", value);
	return ret;
}

long long Long::operator++()
{
	long long temp = value++;
	return temp;
}

long long Long::operator++(int i)
{
	return ++value;
}

long long Long::operator--()
{
	return value--;
}

long long Long::operator--(int i)
{
	return --value;
}

long long Long::operator=(long long i)
{
	return value = i;
}

long long Long::operator=(Long & i)
{
	return value = i.getValue();
}

long long Long::operator=(Short & s)
{
	return value = s.getValue();
}

long long Long::operator+(long long i)
{
	return value + i;
}

long long Long::operator+=(long long i)
{
	return value += i;
}

long long Long::operator+(Long & i)
{
	return value + i.getValue();
}

long long Long::operator+=(Long & i)
{
	return value += i.getValue();
}

long long Long::operator-(long long i)
{
	return value - i;
}

long long Long::operator-=(long long i)
{
	return value -= i;
}

long long Long::operator-(Long & i)
{
	return value - i.getValue();
}

long long Long::operator-=(Long & i)
{
	return value -= i.getValue();
}

long long Long::operator*(long long i)
{
	return value * i;
}

long long Long::operator*=(long long i)
{
	return value *= i;
}

long long Long::operator*(Long & i)
{
	return value * i.getValue();
}

long long Long::operator*=(Long & i)
{
	return value *= i.getValue();
}

long long Long::operator/(long long i)
{
	return value / i;
}

long long Long::operator/=(long long i)
{
	return value /= i;
}

long long Long::operator/(Long & i)
{
	return value / i.getValue();
}

long long Long::operator/=(Long & i)
{
	return value /= i.getValue();
}

long long Long::operator%(long long i)
{
	return value % i;
}

long long Long::operator%=(long long i)
{
	return value %= i;
}

long long Long::operator%(Long & i)
{
	return value % i.getValue();
}

long long Long::operator%=(Long & i)
{
	return value %= i.getValue();
}
