#pragma once
#include "PrimitiveWrapper.h"

class Short;
class Integer;

class Long : public PrimitiveWrapper
{
public:
	Long();
	Long(long long l);
	Long(Long& l);
	Long(Integer& i);
	Long(Short& s);
	~Long();

	long long getValue();
	void setValue(long long i);

	TString toString() override;

	long long operator++(); // Postfix
	long long operator++(int i); // Prefix
	long long operator--(); // Postfix
	long long operator--(int i); // Prefix

	long long operator=(long long i);
	long long operator=(Long& i);
	long long operator=(Short& s);

	long long operator+(long long i);
	long long operator+=(long long i);
	long long operator+(Long& i);
	long long operator+=(Long& i);

	long long operator-(long long i);
	long long operator-=(long long i);
	long long operator-(Long& i);
	long long operator-=(Long& i);

	long long operator*(long long i);
	long long operator*=(long long i);
	long long operator*(Long& i);
	long long operator*=(Long& i);

	long long operator/(long long i);
	long long operator/=(long long i);
	long long operator/(Long& i);
	long long operator/=(Long& i);

	long long operator%(long long i);
	long long operator%=(long long i);
	long long operator%(Long& i);
	long long operator%=(Long& i);

protected:
	long long value;
};

