#pragma once
#include "PrimitiveWrapper.h"

class Short;

class _TREC_LIB_DLL Float :
	public PrimitiveWrapper
{
public:
	Float();
	~Float();

	float getValue();
	void setValue(float i);

	TString toString() override;

	

	float operator=(float i);
	float operator=(Float& i);
	float operator=(Short& s);

	float operator+(float i);
	float operator+=(float i);
	float operator+(Float& i);
	float operator+=(Float& i);

	float operator-(float i);
	float operator-=(float i);
	float operator-(Float& i);
	float operator-=(Float& i);

	float operator*(float i);
	float operator*=(float i);
	float operator*(Float& i);
	float operator*=(Float& i);

	float operator/(float i);
	float operator/=(float i);
	float operator/(Float& i);
	float operator/=(Float& i);

protected:
	float value;
};

