#pragma once
#include "PrimitiveWrapper.h"

class Integer;
class Short;
class Long;

class _TREC_LIB_DLL Boolean :
	public PrimitiveWrapper
{
public:
	Boolean();
	Boolean(bool b);
	Boolean(Boolean& b);
	Boolean(int i);
	Boolean(Integer& i);
	Boolean(Short& s);
	~Boolean();

	bool getValue();
	void setValue(bool i);

	TString toString() override;

	bool operator!();
	bool operator=(bool b);
	bool operator=(Boolean& b);
	bool operator=(int i);
	bool operator=(Integer& i);
	bool operator=(Short& s);

	bool operator&&(bool b);
	bool operator&&(Boolean& b);
	bool operator&&(int i);
	bool operator&&(Integer& i);
	bool operator&&(Short& s);
	bool operator&&(Long& l);

	bool operator&(bool b);
	bool operator&(Boolean& b);
	bool operator&(int i);
	bool operator&(Integer& i);
	bool operator&(Short& s);
	bool operator&(Long& l);

	bool operator|(bool b);
	bool operator|(Boolean& b);
	bool operator|(int i);
	bool operator|(Integer& i);
	bool operator|(Short& s);
	bool operator|(Long& l);

	bool operator||(bool b);
	bool operator||(Boolean& b);
	bool operator||(int i);
	bool operator||(Integer& i);
	bool operator||(Short& s);
	bool operator||(Long& l);

protected:
	bool value;
};

