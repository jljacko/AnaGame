#include "stdafx.h"
#include "Double.h"

#include "Short.h"
#include "Integer.h"
#include "Float.h"

Double::Double()
{
}


Double::~Double()
{
}


double Double::getValue()
{
	return value;
}

void Double::setValue(double i)
{
	value = i;
}

TString Double::toString()
{
	TString ret;
	ret.Format(L"%d", value);
	return ret;
}



double Double::operator=(double i)
{
	return value = i;
}

double Double::operator=(Double & i)
{
	return value = i.getValue();
}

double Double::operator=(Short & s)
{
	return value = s.getValue();
}

double Double::operator=(Integer & i)
{
	return value = i.getValue();
}

double Double::operator=(Float & f)
{
	return value = f.getValue();
}

double Double::operator+(double i)
{
	return value + i;
}

double Double::operator+=(double i)
{
	return value += i;
}

double Double::operator+(Double & i)
{
	return value + i.getValue();
}

double Double::operator+=(Double & i)
{
	return value += i.getValue();
}

double Double::operator-(double i)
{
	return value - i;
}

double Double::operator-=(double i)
{
	return value -= i;
}

double Double::operator-(Double & i)
{
	return value - i.getValue();
}

double Double::operator-=(Double & i)
{
	return value -= i.getValue();
}

double Double::operator*(double i)
{
	return value * i;
}

double Double::operator*=(double i)
{
	return value *= i;
}

double Double::operator*(Double & i)
{
	return value * i.getValue();
}

double Double::operator*=(Double & i)
{
	return value *= i.getValue();
}

double Double::operator/(double i)
{
	return value / i;
}

double Double::operator/=(double i)
{
	return value /= i;
}

double Double::operator/(Double & i)
{
	return value / i.getValue();
}

double Double::operator/=(Double & i)
{
	return value /= i.getValue();
}