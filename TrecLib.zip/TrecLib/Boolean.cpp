#include "stdafx.h"
#include "Boolean.h"

#include "Long.h"
#include "Integer.h"
#include "Short.h"


Boolean::Boolean()
{
	value = false;
}

Boolean::Boolean(bool b)
{
	value = b;
}


Boolean::Boolean(Boolean & b)
{
	value = b.getValue();
}

Boolean::Boolean(int i)
{
	value = i;
}

Boolean::Boolean(Integer & i)
{
	value = i.getValue();
}

Boolean::Boolean(Short & s)
{
	value = s.getValue();
}

Boolean::~Boolean()
{
}

bool Boolean::getValue()
{
	return value;
}

void Boolean::setValue(bool i)
{
	value = i;
}

TString Boolean::toString()
{
	if (value)
		return TString(L"true");
	return TString(L"false");
}

bool Boolean::operator!()
{
	return !value;
}

bool Boolean::operator=(bool b)
{
	return value = b;
}

bool Boolean::operator=(Boolean & b)
{
	return value = b.getValue();
}

bool Boolean::operator=(int i)
{
	return value = i;
}

bool Boolean::operator=(Integer & i)
{
	return value = i.getValue();
}

bool Boolean::operator=(Short & s)
{
	return value = s.getValue();
}

bool Boolean::operator&&(bool b)
{
	return value && b;
}

bool Boolean::operator&&(Boolean & b)
{
	return value && b.getValue();
}

bool Boolean::operator&&(int i)
{
	return value && i;
}

bool Boolean::operator&&(Integer & i)
{
	return value && i.getValue();
}

bool Boolean::operator&&(Short & s)
{
	return value && s.getValue();
}

bool Boolean::operator&&(Long & l)
{
	return value && l.getValue();
}

bool Boolean::operator&(bool b)
{
	return value & b;
}

bool Boolean::operator&(Boolean & b)
{
	return value & b.getValue();
}

bool Boolean::operator&(int i)
{
	return value & i;
}

bool Boolean::operator&(Integer & i)
{
	return value & i.getValue();
}

bool Boolean::operator&(Short & s)
{
	return value & s.getValue();
}

bool Boolean::operator&(Long & l)
{
	return value & l.getValue();
}

bool Boolean::operator|(bool b)
{
	return value | b;
}

bool Boolean::operator|(Boolean & b)
{
	return value | b.getValue();
}

bool Boolean::operator|(int i)
{
	return value || i;
}

bool Boolean::operator|(Integer & i)
{
	return value || i.getValue();
}

bool Boolean::operator|(Short & s)
{
	return value | s.getValue();
}

bool Boolean::operator|(Long & l)
{
	return value | l.getValue();
}

bool Boolean::operator||(bool b)
{
	return value || b;
}

bool Boolean::operator||(Boolean & b)
{
	return value || b.getValue();
}

bool Boolean::operator||(int i)
{
	return value || i;
}

bool Boolean::operator||(Integer & i)
{
	return value || i.getValue();
}

bool Boolean::operator||(Short & s)
{
	return value || s.getValue();
}

bool Boolean::operator||(Long & l)
{
	return value || l.getValue();
}
