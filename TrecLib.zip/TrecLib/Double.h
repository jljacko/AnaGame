#pragma once
#include "PrimitiveWrapper.h"

class Short;
class Integer;
class Float;

class _TREC_LIB_DLL Double :	public PrimitiveWrapper
{
public:
	Double();
	~Double();

	double getValue();
	void setValue(double i);

	TString toString() override;



	double operator=(double i);
	double operator=(Double& i);
	double operator=(Short& s);
	double operator=(Integer& i);
	double operator=(Float& f);

	double operator+(double i);
	double operator+=(double i);
	double operator+(Double& i);
	double operator+=(Double& i);

	double operator-(double i);
	double operator-=(double i);
	double operator-(Double& i);
	double operator-=(Double& i);

	double operator*(double i);
	double operator*=(double i);
	double operator*(Double& i);
	double operator*=(Double& i);

	double operator/(double i);
	double operator/=(double i);
	double operator/(Double& i);
	double operator/=(Double& i);

protected:
	double value;
};

