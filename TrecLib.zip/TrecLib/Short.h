#pragma once
#include "PrimitiveWrapper.h"
class _TREC_LIB_DLL Short :
	public PrimitiveWrapper
{
public:
	Short();
	Short(short s);
	Short(Short& s);
	Short(unsigned char u);
	~Short();

	short  getValue();
	void setValue(short  i);

	TString toString() override;

	short  operator++(); // Postfix
	short  operator++(int  i); // Prefix
	short  operator--(); // Postfix
	short  operator--(int  i); // Prefix

	short  operator+(short  i);
	short  operator+=(short  i);
	short  operator+(Short& i);
	short  operator+=(Short& i);

	short  operator-(short  i);
	short  operator-=(short  i);
	short  operator-(Short& i);
	short  operator-=(Short& i);

	short  operator*(short  i);
	short  operator*=(short  i);
	short  operator*(Short& i);
	short  operator*=(Short& i);

	short  operator/(short  i);
	short  operator/=(short  i);
	short  operator/(Short& i);
	short  operator/=(Short& i);

	short  operator%(short  i);
	short  operator%=(short  i);
	short  operator%(Short& i);
	short  operator%=(Short& i);

protected:
	short  value;
};

