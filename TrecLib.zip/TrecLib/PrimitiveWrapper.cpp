#include "stdafx.h"
#include "PrimitiveWrapper.h"


PrimitiveWrapper::PrimitiveWrapper()
{
}


PrimitiveWrapper::~PrimitiveWrapper()
{
}
