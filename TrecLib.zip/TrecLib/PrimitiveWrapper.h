#pragma once
#include "TObject.h"
#include "TString.h"

class _TREC_LIB_DLL PrimitiveWrapper : public TObject
{
public:
	PrimitiveWrapper();
	~PrimitiveWrapper();
};

