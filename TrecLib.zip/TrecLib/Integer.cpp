#include "stdafx.h"
#include "Integer.h"
#include "Short.h"

Integer::Integer()
{
}

Integer::Integer(int i)
{
	value = i;
}

Integer::Integer(USHORT s)
{
	value = s;
}

Integer::Integer(Integer & i)
{
	value = i.getValue();
}


Integer::~Integer()
{
}

int Integer::getValue()
{
	return value;
}

void Integer::setValue(int i)
{
	value = i;
}

TString Integer::toString()
{
	TString ret;
	ret.Format(L"%d", value);
	return ret;
}

int Integer::operator++()
{
	int temp = value++;
	return temp;
}

int Integer::operator++(int i)
{
	return ++value;
}

int Integer::operator--()
{
	return value--;
}

int Integer::operator--(int i)
{
	return --value;
}

int Integer::operator=(int i)
{
	return value = i;
}

int Integer::operator=(Integer & i)
{
	return value = i.getValue();
}

int Integer::operator=(Short & s)
{
	return value = s.getValue();
}

int Integer::operator+(int i)
{
	return value + i;
}

int Integer::operator+=(int i)
{
	return value += i;
}

int Integer::operator+(Integer & i)
{
	return value + i.getValue();
}

int Integer::operator+=(Integer & i)
{
	return value += i.getValue();
}

int Integer::operator-(int i)
{
	return value - i;
}

int Integer::operator-=(int i)
{
	return value -= i;
}

int Integer::operator-(Integer & i)
{
	return value - i.getValue();
}

int Integer::operator-=(Integer & i)
{
	return value -= i.getValue();
}

int Integer::operator*(int i)
{
	return value * i;
}

int Integer::operator*=(int i)
{
	return value *= i;
}

int Integer::operator*(Integer & i)
{
	return value * i.getValue();
}

int Integer::operator*=(Integer & i)
{
	return value *= i.getValue();
}

int Integer::operator/(int i)
{
	return value / i;
}

int Integer::operator/=(int i)
{
	return value /= i;
}

int Integer::operator/(Integer & i)
{
	return value / i.getValue();
}

int Integer::operator/=(Integer & i)
{
	return value /= i.getValue();
}

int Integer::operator%(int i)
{
	return value % i;
}

int Integer::operator%=(int i)
{
	return value %= i;
}

int Integer::operator%(Integer & i)
{
	return value % i.getValue();
}

int Integer::operator%=(Integer & i)
{
	return value %= i.getValue();
}
