#include "stdafx.h"
#include "Short.h"


Short::Short()
{
}

Short::Short(short s)
{
	value = s;
}


Short::Short(Short & s)
{
	value = s.getValue();
}

Short::Short(unsigned char u)
{
	value = u;
}

Short::~Short()
{
}


short Short::getValue()
{
	return value;
}

void Short::setValue(short i)
{
	value = i;
}

TString Short::toString()
{
	TString ret;
	ret.Format(L"%d", value);
	return ret;
}

short Short::operator++()
{
	short temp = value++;
	return temp;
}

short Short::operator++(int i)
{
	return ++value;
}

short Short::operator--()
{
	return value--;
}

short Short::operator--(int i)
{
	return --value;
}

short Short::operator+(short i)
{
	return value + i;
}

short Short::operator+=(short i)
{
	return value += i;
}

short Short::operator+(Short & i)
{
	return value + i.getValue();
}

short Short::operator+=(Short & i)
{
	return value += i.getValue();
}

short Short::operator-(short i)
{
	return value - i;
}

short Short::operator-=(short i)
{
	return value -= i;
}

short Short::operator-(Short & i)
{
	return value - i.getValue();
}

short Short::operator-=(Short & i)
{
	return value -= i.getValue();
}

short Short::operator*(short i)
{
	return value * i;
}

short Short::operator*=(short i)
{
	return value *= i;
}

short Short::operator*(Short & i)
{
	return value * i.getValue();
}

short Short::operator*=(Short & i)
{
	return value *= i.getValue();
}

short Short::operator/(short i)
{
	return value / i;
}

short Short::operator/=(short i)
{
	return value /= i;
}

short Short::operator/(Short & i)
{
	return value / i.getValue();
}

short Short::operator/=(Short & i)
{
	return value /= i.getValue();
}

short Short::operator%(short i)
{
	return value % i;
}

short Short::operator%=(short i)
{
	return value %= i;
}

short Short::operator%(Short & i)
{
	return value % i.getValue();
}

short Short::operator%=(Short & i)
{
	return value %= i.getValue();
}