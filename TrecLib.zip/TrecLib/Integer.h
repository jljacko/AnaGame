#pragma once
#include "PrimitiveWrapper.h"
class Short;

class _TREC_LIB_DLL Integer :	public PrimitiveWrapper
{
public:
	Integer();
	Integer(int i);
	Integer(USHORT s);
	Integer(Integer& i);
	~Integer();

	int getValue();
	void setValue(int i);

	TString toString() override;

	int operator++(); // Postfix
	int operator++(int i); // Prefix
	int operator--(); // Postfix
	int operator--(int i); // Prefix

	int operator=(int i);
	int operator=(Integer& i);
	int operator=(Short& s);

	int operator+(int i);
	int operator+=(int i);
	int operator+(Integer& i);
	int operator+=(Integer& i);

	int operator-(int i);
	int operator-=(int i);
	int operator-(Integer& i);
	int operator-=(Integer& i);

	int operator*(int i);
	int operator*=(int i);
	int operator*(Integer& i);
	int operator*=(Integer& i);

	int operator/(int i);
	int operator/=(int i);
	int operator/(Integer& i);
	int operator/=(Integer& i);

	int operator%(int i);
	int operator%=(int i);
	int operator%(Integer& i);
	int operator%=(Integer& i);

protected:
	int value;
};

