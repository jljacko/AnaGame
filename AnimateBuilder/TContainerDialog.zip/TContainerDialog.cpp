// TContainerDialog.cpp : implementation file
//

#include "stdafx.h"
#include "AnimateBuilder.h"
#include "TContainerDialog.h"
#include "afxdialogex.h"


// TContainerDialog dialog

IMPLEMENT_DYNAMIC(TContainerDialog, CDialogEx)

TContainerDialog::TContainerDialog(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG4, pParent)
{
	contain = nullptr;
}

TContainerDialog::~TContainerDialog()
{
}

TrecPointer<TContainer> TContainerDialog::getContainer()
{
	return contain;
}

void TContainerDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(TContainerDialog, CDialogEx)
	ON_BN_CLICKED(IDOK, &TContainerDialog::OnBnClickedOk)
END_MESSAGE_MAP()


// TContainerDialog message handlers


void TContainerDialog::OnBnClickedOk()
{
	// TODO: Add your control notification handler code here
	TString string;
	contain = new TContainer();
	if (!contain.get())
		goto Okay;
	RECT r;
	r.top = 20;
	r.left = 20;
	r.bottom = 30;
	r.right = 30;

	CEdit* edit = (CEdit*)GetDlgItem(IDC_EDIT1);

	if (edit)
	{
		edit->GetWindowTextW(string);
		string.ConvertToLong(&r.left);
	}
	edit = (CEdit*)GetDlgItem(IDC_EDIT2);

	if (edit)
	{
		edit->GetWindowTextW(string);
		string.ConvertToLong(&r.top);
	}
	edit = (CEdit*)GetDlgItem(IDC_EDIT3);

	if (edit)
	{
		edit->GetWindowTextW(string);
		string.ConvertToLong(&r.right);
	}
	edit = (CEdit*)GetDlgItem(IDC_EDIT4);

	if (edit)
	{
		edit->GetWindowTextW(string);
		string.ConvertToLong(&r.bottom);
	}
	contain->setLocation(r);

	Okay:
	CDialogEx::OnOK();
}
