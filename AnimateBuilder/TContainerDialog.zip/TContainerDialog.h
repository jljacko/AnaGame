#pragma once
#include "stdafx.h"
#include <TControl.h>
// TContainerDialog dialog

class TContainerDialog : public CDialogEx
{
	DECLARE_DYNAMIC(TContainerDialog)

public:
	TContainerDialog(CWnd* pParent = NULL);   // standard constructor
	virtual ~TContainerDialog();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG4 };
#endif

	//TrecPointer<TContainer> getContainer();

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	TrecPointer<TContainer> contain;
};
